The files are too big to be uploaded to GitHub. Can be downloaded from the following link: https://www.kaggle.com/datasets/zalando-research/fashionmnist
